import turtle
#nbrsides = 5
#for weirdname in range(nbrsides) :
#    turtle.forward(100)
#    turtle.right(360/nbrsides)
#    for steps in range(nbrsides) :
#        turtle.forward(50) 
#        turtle.right(360/nbrsides)

for colour in ['red','green','blue','black'] :
    turtle.color(colour)
    turtle.forward(100)
    turtle.left(90)







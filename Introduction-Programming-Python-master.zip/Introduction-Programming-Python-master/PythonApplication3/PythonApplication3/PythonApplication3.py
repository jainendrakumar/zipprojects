print('Hello World')
i = 1
i += 1
print(i)

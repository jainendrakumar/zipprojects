salary = input("please enter your salary ")
bonus = input("please enter your bonus ")

paycheckAmount = float(salary) + float(bonus)

print(paycheckAmount)
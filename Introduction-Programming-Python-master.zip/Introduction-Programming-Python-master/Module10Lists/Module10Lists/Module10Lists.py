guests = ['Susan','Christopher','Bill','Satya','Sonal']

#option two for looping through a list
for currentGuest in guests :
    print(currentGuest)

##option one for looping through a list
#nbrValueInList = len(guests)

#for steps in range(nbrValueInList) :
#    print(guests[steps])


#remove a value from the list
#guests.remove('Satya')
#del guests[0]
#print (guests[0])
#print (guests[-1])


##add a value
#guests.append('Colin')
#print (guests[-1])

##update a value
#guests[3] = 'Sonal'
#print (guests[3])






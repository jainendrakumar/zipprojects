import datetime

currentDate = datetime.datetime.today()
#print(currentDate.minute)
#print(currentDate)
#print(currentDate.month)
#print(currentDate.year)

#print(currentDate.strftime('%d %b, %Y'))
#print(currentDate.strftime('%d %b %y'))



#userInput = input('Please enter your birthday (mm/dd/yyyy)')
#birthday = datetime.datetime.strptime(userInput, '%m/%d/%Y').date()
#print(birthday)

#days = birthday - currentDate
#print(days.days)
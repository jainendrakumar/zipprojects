#Collect name from the user
name = input('What is your name? ')
country = input('What country do you live in? ')
country = country.upper()

#Display the name
#print(name)

#Create a friendly output
print('\nHello, ' + name + '. You live in ' + country)


#Update the value
#name = 'Christopher Harrison'
#print(name)
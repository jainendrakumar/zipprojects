#meanwhile earlier in the day
bestTeam = "senators"

#if statements with strings
#favouriteTeam = input("What is your favourite hockey team? ")
#if favouriteTeam.upper() == bestTeam.upper() :
#    print("Yeah Go Sens Go")
#    print("But I miss Alfredsson")
#print ("It's okay if you prefer football/soccer")

#if with numbers
freeToaster = None 

deposit = int(input("how much do you want to deposit "))
if deposit > 100 :
    freeToaster = True

#complex code here...
if freeToaster :
    print("enjoy your toaster")
print("Have a nice day!")

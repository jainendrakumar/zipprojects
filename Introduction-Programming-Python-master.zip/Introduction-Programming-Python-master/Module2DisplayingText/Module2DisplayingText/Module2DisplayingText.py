print('The capybara is the worlds largest rodent')
print('The capybara likes to live in groups')
print("The capybara can swim")

print("the capybara lives in \nSouth America")
print("""This is the strangest
way to print over multiple lines I know""")

print('here is a double quote "' + " here is a single quote '")
print("or you can just do this \" does that work")
print("can I just print a \ on the screen?")

#I am inserting a \\ so the \ appears correctly in the string
print("But what if I want \\news ")




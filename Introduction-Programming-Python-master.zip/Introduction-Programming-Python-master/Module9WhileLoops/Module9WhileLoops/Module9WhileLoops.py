import turtle

counter = 0
while counter < 4:
    turtle.forward(100)
    turtle.right(90)
    counter += 1 # This is the exact same thing as counter = counter + 1


#answer = '0'

#while answer != '42':
#    answer = input('What is the answer to the ultimate question of life, the universe and everything? ')

#print('Congratulations - you are right!!')
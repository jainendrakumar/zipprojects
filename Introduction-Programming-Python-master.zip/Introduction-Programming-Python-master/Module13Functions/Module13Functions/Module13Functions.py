import helpers

#Define this function
#When someone calls this function, execute this code
def main():
    names = helpers.getNames()
    helpers.printNames(names)
    return

#Execute the main function
#In order to do that the function must be created
#Start the program
main() 
